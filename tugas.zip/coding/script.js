const holes = document.querySelectorAll(".hole");

const scoreDisplay =
    document.getElementById("score");

const timeLeftDisplay =
    document.getElementById("time-left");

const startButton =
    document.getElementById("start-btn");


let score = 0;

let timeLeft = 30;

let gameRunning = false;

let timer;

let moleTimer;


// Memilih lubang secara acak
function randomHole() {

    const randomNumber =
        Math.floor(Math.random() * holes.length);

    return holes[randomNumber];

}


// Menghilangkan mole dari semua lubang
function removeMoles() {

    holes.forEach(function(hole) {

        hole.classList.remove("active");

        hole.onclick = null;

    });

}


// Menampilkan mole
function showMole() {

    if (!gameRunning) {
        return;
    }

    removeMoles();

    const hole = randomHole();

    hole.classList.add("active");


    hole.onclick = function() {

        if (!gameRunning) {
            return;
        }


        score++;

        scoreDisplay.textContent = score;


        hole.classList.remove("active");

        hole.onclick = null;


        showMole();

    };


    moleTimer = setTimeout(function() {

        showMole();

    }, 800);

}


// Memulai timer
function startTimer() {

    timer = setInterval(function() {

        timeLeft--;

        timeLeftDisplay.textContent =
            timeLeft;


        if (timeLeft <= 0) {

            endGame();

        }

    }, 1000);

}


// Memulai game
function startGame() {

    if (gameRunning) {
        return;
    }


    score = 0;

    timeLeft = 30;


    scoreDisplay.textContent =
        score;

    timeLeftDisplay.textContent =
        timeLeft;


    gameRunning = true;


    startButton.disabled = true;

    startButton.textContent =
        "Game Running...";


    showMole();

    startTimer();

}


// Mengakhiri game
function endGame() {

    gameRunning = false;


    clearInterval(timer);

    clearTimeout(moleTimer);


    removeMoles();


    startButton.disabled = false;

    startButton.textContent =
        "Start Game";


    alert(
        "Game Over!\nYour Score: "
        + score
    );

}


// Tombol Start
startButton.addEventListener(
    "click",
    startGame
);